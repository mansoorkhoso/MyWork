
public class ShippingBox {
	public String sender_name;
	public String receiver_name;
	public int cost_per_pound;
	public int weight;
	
	
	public int cal_cost(){
		return this.cost_per_pound*this.weight;
	}
}
