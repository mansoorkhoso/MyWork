
public class MyFirstClass {

	public static void main(String[] args) {
		ShippingBox sb = new ShippingBox();
		sb.sender_name = "Ali";
		sb.cost_per_pound = 10;
		sb.receiver_name = "Mak";
		sb.weight =10;
		
		ShippingBox sb1 = new ShippingBox();
		sb1.sender_name ="Mansoor";
		sb1.cost_per_pound = 20;
		sb1.receiver_name = "Khalid";
		sb1.weight = 5;
		
		Car c = new Car();
		c.type = "ford";
		c.color = "blue";
		c.model = 2011;
		
		Student std= new Student();
		std.student_name = " Saleem";
		std.student_course ="OOP";
		std.student_ID = 12345;
		
		
		System.out.println("\tShipping Box\n");
		
		System.out.println("Sender " + sb.sender_name);
		System.out.println("Cost per pound " + sb.cost_per_pound);
		System.out.println("Receiver Name " + sb.receiver_name);
		System.out.println("Weight " + sb.weight);
		
		System.out.println("=====================");
		
		System.out.println("Sender " + sb1.sender_name);
		System.out.println("Cost per pound " + sb1.cost_per_pound);
		System.out.println("Receiver Name " + sb1.receiver_name);
		System.out.println("Weight " + sb1.weight);
		
		
		System.out.println("=====================");
		
		System.out.println("\tCar Data\n");
		System.out.println("Type " +c.type);
		System.out.println("Color " + c.color);
		System.out.println("Model " + c.model);
		
		
		System.out.println("=====================");
		
		System.out.println("\tStudent Info\n");
		System.out.println("Student Name " + std.student_name);
		System.out.println("Studnet Course " + std.student_course);
		System.out.println("Student ID " + std.student_ID);
		
		
		
	}

}
