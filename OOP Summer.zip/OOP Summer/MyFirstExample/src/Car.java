
public class Car {
	
	String type;
	String color;
	int model;
	

}
