
public class Student {
		
	String student_name;
	String student_course;
	int student_ID;
	
}
